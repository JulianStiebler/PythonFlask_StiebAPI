.. module:: itsdangerous.encoding

Encoding Utilities
==================

.. autofunction:: base64_encode

.. autofunction:: base64_decode
