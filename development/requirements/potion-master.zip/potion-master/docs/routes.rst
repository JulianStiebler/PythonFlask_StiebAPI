
Routes & Route Sets
===================

.. module:: routes


.. autoclass:: Route
    :members:

.. autoclass:: ItemRoute
    :members:

|

.. autoclass:: RouteSet
    :members:

|

.. autoclass:: Relation
    :members:



.. autoclass:: ItemAttributeRoute
    :members: