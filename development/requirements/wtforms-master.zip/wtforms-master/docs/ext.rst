:orphan:

Extensions
==========

All WTForms extensions were removed in WTForms 3.0.

 * ``wtforms.ext.appengine`` was extracted to `WTForms-Appengine <https://github.com/wtforms/wtforms-appengine>`_
 * ``wtforms.ext.csrf`` was integrated into WTForms core. See :doc:`CSRF Docs <csrf>`
 * ``wtforms.ext.django`` was extracted to `WTForms-Django <https://github.com/wtforms/wtforms-django>`_
 * ``wtforms.ext.i18n`` was integrated into WTForms core. See :doc:`i18n`
 * ``wtforms.ext.sqlalchemy`` was extracted to `WTForms-SQLAlchemy <https://github.com/wtforms/wtforms-sqlalchemy>`_
