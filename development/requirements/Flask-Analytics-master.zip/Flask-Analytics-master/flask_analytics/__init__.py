from flask_analytics.analytics import Analytics
