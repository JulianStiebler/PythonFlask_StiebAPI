class BaseProvider(object):

    pass
