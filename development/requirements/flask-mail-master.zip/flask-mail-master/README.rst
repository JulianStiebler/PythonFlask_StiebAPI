Flask-Mail
==========

.. image:: https://secure.travis-ci.org/mattupstate/flask-mail.png?branch=master

Flask-Mail is a Flask extension providing simple email sending capabilities.

Documentation: http://packages.python.org/Flask-Mail