Tutorial
========

The tutorial for flask-praetorian has been moved into its own project:

`tutorial github repo <https://github.com/dusktreader/flask-praetorian-tutorial/>`_
`tutorial readthedocs <https://flask-praetorian-tutorial.readthedocs.io/en/latest/>`_
