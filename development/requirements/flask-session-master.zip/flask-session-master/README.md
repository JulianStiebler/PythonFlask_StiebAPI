Flask-Session
=============

Flask-Session is an extension for Flask that adds support for Server-side Session to your application.
