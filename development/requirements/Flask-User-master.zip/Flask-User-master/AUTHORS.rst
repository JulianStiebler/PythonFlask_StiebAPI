Authors
-------
| **Lead developer and Maintainer**
| Ling Thio -- ling.thio AT gmail DOT com
|
| **Contributors**
| `Many contributors <https://github.com/lingthio/Flask-User/graphs/contributors>`_
